import pandas as pd
from flask import Flask, jsonify ,request


app = Flask(__name__) 


#games_df = pd.read_csv("data/games.csv")
simulations_df = pd.read_csv("data/simulations.csv")
simulations_df = simulations_df.drop('team_id', axis=1)
venues_df = pd.read_csv("data/venues.csv")
# Self-join based on simulation_run
merged_df = pd.merge(simulations_df, simulations_df, on='simulation_run', how='inner', suffixes=('_home', '_away'))
 

#print(transformed_data)

@app.route("/games")
def home():
    home_team = request.args.get('home')
    
    # Filter by home team value
    #home_team = 'Peterborough Strikers'
    home_team = request.args.get('home')
    filtered_df = merged_df[merged_df['team_home'] == home_team]
    filtered_df['home_team_win'] = (filtered_df['results_home'] > filtered_df['results_away']).astype(int)
    filtered_df = filtered_df[['team_away', 'home_team_win']]
    agg_df = (filtered_df.groupby('team_away')
            .agg(
                home=('home_team_win', 'sum'),                           
            )).sort_index(axis=1)

    agg_df['away'] = (100-agg_df['home'])/100
    agg_df['home'] = (agg_df['home'])/100

    #print(jsonify(agg_df.to_dict(orient='records')))
    transformed_data = { "home": agg_df['home'].values.tolist(), "away": agg_df['away'].values.tolist()}
    print(transformed_data)
    return jsonify(transformed_data)

if __name__ == "__main__":
    app.run(host="0.0.0.0")