
import React from 'react';
import { useEffect, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';


ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const options = {
  responsive: true,
  plugins: {
    legend: {
      position: 'bottom',
    },
    title: {
      display: true,
      text: 'Histogram',
    },
  },
};
 function App() {

  const [apiData, setApiData] = useState(null);

  useEffect(() => {
    // Fetch data from the API
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:5000/games?home=Doncaster Renegades');
        const result = await response.json();
        setApiData(result);
        // Log the response to the console
        console.log('API Response:', result);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []); // Empty dependency array ensures the effect runs only once after the initial render

  const labels = ['Blackburn Knight Riders', 'Blackpool Sixers', 'Castleford Thunder', 'Doncaster Renegades', 'Huddersfield Heat', 'Hull Stars', 'Oldham Super Kings', 'Peterborough Strikers', 'Rochdale Hurricanes', 'Rotherham Scorchers'];

  const data = {
    labels,
    datasets: [
      {
        label: 'Home',
        data: apiData?.home || [],
        backgroundColor: 'grey',
      },
      {
        label: 'Away',
        data: apiData?.away || [],
        backgroundColor: 'Red',
      },
    ],
  };

  return <Bar options={options} data={data} />;
}
export default App;